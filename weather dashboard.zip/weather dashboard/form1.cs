﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;

namespace WeatherDashboard
{
    public partial class Form1 : Form
    {
        private const string API_KEY = "YOUR_API_KEY"; // Replace with OpenWeatherMap API key

        public Form1()
        {
            InitializeComponent();
        }

        private async void btnGetWeather_Click(object sender, EventArgs e)
        {
            string city = txtCity.Text.Trim();

            if (string.IsNullOrEmpty(city))
            {
                MessageBox.Show("Please enter a city name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string weatherData = await GetWeatherData(city);

                if (weatherData != null)
                {
                    var json = JObject.Parse(weatherData);

                    string resultText =
                        $"🌍 City: {json["name"]}, {json["sys"]["country"]}\n" +
                        $"🌡 Temp: {json["main"]["temp"]} °C\n" +
                        $"💧 Humidity: {json["main"]["humidity"]}%\n" +
                        $"🌬 Wind: {json["wind"]["speed"]} m/s\n" +
                        $"☁ Condition: {json["weather"][0]["description"]}";

                    lblResult.Text = resultText;
                }
                else
                {
                    lblResult.Text = "❌ City not found.";
                }
            }
            catch (Exception ex)
            {
                lblResult.Text = $"Error: {ex.Message}";
            }
        }

        private async Task<string> GetWeatherData(string city)
        {
            string url = $"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric";

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
